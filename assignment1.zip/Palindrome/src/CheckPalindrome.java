public class CheckPalindrome {

    public static void main(String[] args) {

        String s = "anna";
        String s1 = "MAD";
        String s2 = "madam";
        String reverse = "";
        String reverse2 = "";

        for (int i = s.length() - 1; i >= 0; i--) {
            reverse2 = reverse2 + s.charAt(i);
        }
        for (int j = s2.length() - 1; j >= 0; j--) {
            reverse = reverse + s2.charAt(j);
        }

        if(s.equals(reverse2) || s2.equals(reverse)){
            System.out.println("Palindrome");
        }
        else
        {
            System.out.println("not Palindrome");
        }
            }
        }
