package com.burhan.palindromburhan;

import android.widget.Toast;

public class MyString {
    public String str;

    public MyString(String str) {
        this.str = str;
    }

    public boolean isPalindrome() {

        String reverse2 = "";

        for (int i = str.length() - 1; i >= 0; i--) {
            reverse2 = reverse2 + str.charAt(i);
        }
        if (str.equals(reverse2)) {
            System.out.println("Palindrome");
            return true;
        } else {
            System.out.println("not Palindrome");
            return false;

        }


    }

}
