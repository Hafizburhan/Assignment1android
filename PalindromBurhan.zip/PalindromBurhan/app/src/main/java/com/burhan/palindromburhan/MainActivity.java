package com.burhan.palindromburhan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    MyString text;
    EditText etText;
    Button btnText;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etText = findViewById(R.id.etText);
        btnText = findViewById(R.id.btnText);
        result = findViewById(R.id.result);



        btnText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                text = new MyString(etText.getText().toString());
                if (text.isPalindrome()) {
                    result.setText("Palindrome");
                    etText.setText("");
                } else {
                    etText.setText("");
                    result.setText("Not Palindrome");
                }

            }
        });


    }
}